﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.CommonUtility;

namespace BusinessRuleEngine.IBusinessComponents
{
    public interface IBusinessRuleBC
    {
        bool ConnectDB();

        void ApplyRule(enuPaymnentRuleType rule);
    }
}
