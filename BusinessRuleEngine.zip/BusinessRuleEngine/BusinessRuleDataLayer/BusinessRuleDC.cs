﻿using BusinessRule.IDataAcessComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRule.DataAcessComponents
{
    public class BusinessRuleDC : IBusinessRuleDC
    {
        //declare class dependency injection object
        //private readonly IBusinessRuleDC _DCInstance = ObjectFactory.GetInstance("IBusinessRuleDC") as IBusinessRuleDC;

        public bool ConnectDB()
        {
            //call interface cnnnect db
            //_DCInstance.ConnectDB();
            throw new NotImplementedException();
        }
    }
}
