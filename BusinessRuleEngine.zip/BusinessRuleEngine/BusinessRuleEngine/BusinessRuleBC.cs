﻿using BusinessRuleEngine.IBusinessComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Common.CommonUtility;

namespace BusinessRuleEngine.BusinessComponents
{
    public class BusinessRuleBC : IBusinessRuleBC
    {
        public void ApplyRule(enuPaymnentRuleType rule)
        {
            try
            {

                //• If the payment is for a physical product, generate a packing slip for shipping.
                //• If the payment is for a book, create a duplicate packing slip for the royalty department.
                //• If the payment is for a membership, activate that membership.
                //• If the payment is an upgrade to a membership, apply the upgrade.
                //• If the payment is for a membership or upgrade, e - mail the owner and inform them of the activation / upgrade.
                //• If the payment is for the video “Learning to Ski,” add a free “First Aid” video to the packing slip(the result of a court decision in 1997).
                //• If the payment is for a physical product or a book, generate a commission payment to the agent.
                if (rule == enuPaymnentRuleType.PhysicalProduct)
                {
                    // perform packing slip for shipping
                    // generate a commission payment to the agent.
                }
                else 
                if (rule == enuPaymnentRuleType.Book)
                {
                    // perform duplicate packing slip for the royalty department
                    // generate a commission payment to the agent.
                }
                else 
                if (rule == enuPaymnentRuleType.Membership)
                {
                    // perform activate that membership
                    //e - mail the owner and inform them of the activation / upgrade.
                }
                else 
                if (rule == enuPaymnentRuleType.UpgradeMembership)
                {
                    // perform apply the upgrade.
                    //e - mail the owner and inform them of the activation / upgrade.
                }
                else 
                if (rule == enuPaymnentRuleType.VideoLearn)
                {
                    // perform  add a free “First Aid” video to the packing slip
                } 
            }
            catch (Exception)
            {

                throw;
            }
                
        }

        //declare class dependency injection object
        //private readonly IBusinessRuleBC _BCInstance = ObjectFactory.GetInstance("IBusinessRuleBC") as IBusinessRuleBC;
        public bool ConnectDB()
        {
            //call interface cnnnect db
            //_BCInstance.ConnectDB();
            throw new NotImplementedException();
        }
    }
}
