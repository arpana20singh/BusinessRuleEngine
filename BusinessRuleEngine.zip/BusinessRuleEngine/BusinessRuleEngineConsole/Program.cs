﻿using Autofac;
using BusinessRule.DataAcessComponents;
using BusinessRule.IDataAcessComponents;
using BusinessRuleEngine.BusinessComponents;
using BusinessRuleEngine.IBusinessComponents;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessRuleEngineConsole
{
    class Program
    {
        // Created by Arpana Singh
        // Used FACADE Design pattern
        // Used dependecy injections to create object

        public static readonly ILog logger = LogManager.GetLogger(typeof(Program));
        static void Main(string[] args)
        {
            try
            {
                logger.Info(string.Format("Starting the program at : " + DateTime.Now));
                var builder = new ContainerBuilder();
                builder.RegisterType<BusinessRuleBC>().As<IBusinessRuleBC>();
                builder.RegisterType<BusinessRuleDC>().As<IBusinessRuleDC>(); 
                var container = builder.Build(); 


            }
            catch (Exception ex)
            {
                logger.Error(string.Format("Exception :=>  Message {0} Stack Trace :{1}", ex.Message, ex.StackTrace));
            }
        }
    }
}
