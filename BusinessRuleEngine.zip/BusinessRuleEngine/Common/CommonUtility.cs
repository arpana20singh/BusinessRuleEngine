﻿namespace Common
{
    public class CommonUtility
    {
        public CommonUtility()
        {
            // All the initial common declarations should go here
        }
        public enum enuPaymnentRuleType
        {
            PhysicalProduct,
            Book,
            Membership,
            UpgradeMembership,
            VideoLearn 
        }

    }
}
